export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gray-100 text-black">
      <h1 className="text-3xl font-bold">Chào mừng đến với WebApp Chứng khoán</h1>
    </main>
  );
}
